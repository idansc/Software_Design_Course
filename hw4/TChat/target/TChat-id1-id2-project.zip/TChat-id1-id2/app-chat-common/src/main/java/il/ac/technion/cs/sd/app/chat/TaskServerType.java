/**
 * 
 */
package il.ac.technion.cs.sd.app.chat;

/**
 * @author idansc
 *
 */
enum TaskServerType {
	LOGIN,
	JOIN_ROOM,
	LEAVE_ROOM,
	LOGOUT,
	SEND_MESSAGE,
	GET_JOINED_ROOM,
	GET_ALL_ROOMS,
	GET_CLIENTS_IN_ROOM,	
}

