package il.ac.technion.cs.sd.lib;

public class CommunicationFailure extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1672758224119850863L;

}
