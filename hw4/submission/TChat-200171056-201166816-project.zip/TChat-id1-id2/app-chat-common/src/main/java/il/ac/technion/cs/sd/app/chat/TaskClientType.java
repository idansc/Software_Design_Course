package il.ac.technion.cs.sd.app.chat;

enum TaskClientType {
	MESSAGE,
	ANNOUNCEMENT
}
