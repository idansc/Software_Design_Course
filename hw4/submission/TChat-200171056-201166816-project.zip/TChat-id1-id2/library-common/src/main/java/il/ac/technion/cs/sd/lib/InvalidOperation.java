package il.ac.technion.cs.sd.lib;

public class InvalidOperation extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3521178545485640506L;

}
