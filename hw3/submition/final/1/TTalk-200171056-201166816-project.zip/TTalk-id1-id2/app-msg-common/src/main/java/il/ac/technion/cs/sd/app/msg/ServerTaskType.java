/**
 * 
 */
package il.ac.technion.cs.sd.app.msg;

/**
 * @author idansc
 *
 */
public enum ServerTaskType {
	LOGIN_TASK,
	LOGOUT_TASK,
	SEND_MESSAGE_TASK,
	REQUEST_FRIENDSHIP_TASK,
	IS_ONLINE_TASK,
	CLIENT_REPLY_FRIEND_REQUEST_TASK
}
