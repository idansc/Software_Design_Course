package il.ac.technion.cs.sd.lib.clientserver;

public class InvalidOperation extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
