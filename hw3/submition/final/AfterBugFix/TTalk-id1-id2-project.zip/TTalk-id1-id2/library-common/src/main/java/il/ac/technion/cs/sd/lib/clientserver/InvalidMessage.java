package il.ac.technion.cs.sd.lib.clientserver;

public class InvalidMessage extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
}
